clear 

cd "/Users/steffinshibu/Desktop/Thesis Work/InvMigUndUncert/Data"

************************** TOP 10 RECEIVING COUNTRIES **************************
use "Window_Panel.dta", clear
collapse (sum) flow, by(iso2_des window_label)
bysort window_label (flow): gen rank_in = _N - _n + 1
bysort window_label: keep if rank_in <= 10

*************************** TOP 10 SENDING COUNTRIES ***************************
use "Window_Panel.dta", clear
collapse (sum) flow, by(iso2_ori window_label)
bysort window_label (flow): gen rank_in = _N - _n + 1
bysort window_label: keep if rank_in <= 10

************************ TOP 10 BILATERAL CORRIDORS ****************************
use "Window_Panel.dta", clear
keep if inlist(window_label, "1993-1997", "2008-2012")
bysort window_label (flow): gen rank = _N - _n + 1
bysort window_label: keep if rank <= 10

************************ UNIQUE COUNTRY LIST ***********************************
use "Window_Panel.dta", clear
bysort iso2_ori: keep if _n == 1
list iso2_ori

use "Window_Panel.dta", clear
bysort iso2_des: keep if _n == 1
list iso2_des
