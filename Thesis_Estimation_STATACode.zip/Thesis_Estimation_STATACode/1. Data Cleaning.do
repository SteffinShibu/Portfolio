clear

cd "/Users/steffinshibu/Desktop/Thesis Work/InvMigUndUncert/Data"

****************** CITATION COUNT CLEANING *************************************
import delimited "Citation_Count_200 Countries.csv", clear varnames(1)
describe
destring v2-v18, replace ignore("-")
forvalues i = 2/18 {
    local yr = 1994 + `i'
    rename v`i' y`yr'
}
forvalues y = 1988/1995 {
    gen y`y' = .
}
order y1988-y1995, first
order country, first
duplicates report country
duplicates list country
duplicates drop country, force
reshape long y, i(country) j(year)
rename y Citation_Count
rename countr Country_Name
save "Citation_Count_199Countries.dta", replace

****************** INTERNATIONAL COLLABORATION CLEANING ************************
import delimited "International_Collaboration_200 Countries.csv", clear varnames(1)
describe
destring v2-v18, replace ignore("-")
forvalues i = 2/18 {
    local yr = 1994 + `i'
    rename v`i' y`yr'
}
forvalues y = 1988/1995 {
    gen y`y' = .
}
order y1988-y1995, first
order countries, first
duplicates report countries
duplicates list countries
duplicates drop countries, force
reshape long y, i(countries) j(year)
rename y International_Collaboration
rename countries Country_Name
save "International_Collaboration_199Countries.dta", replace

****************** SCHOLARLY OUTPUT CLEANING ***********************************
import delimited "Scholarly_Output_200 Countries.csv", clear varnames(1)
describe
destring v2-v18, replace ignore("-")
forvalues i = 2/18 {
    local yr = 1994 + `i'
    rename v`i' y`yr'
}
forvalues y = 1988/1995 {
    gen y`y' = .
}
order y1988-y1995, first
order countries, first
duplicates report countries
duplicates list countries
duplicates drop countries, force
reshape long y, i(countries) j(year)
rename y Scholarly_Output
rename countries Country_Name
save "Scholarly_Output_199Countries.dta", replace

***************** NUMBER OF AUTHORS CLEANING ***********************************
import delimited "Authors.csv", clear varnames(1)

rename number_of_authors_scopus Authors_Scopus
rename number_of_authors_openalex Authors_OpenAlex
rename number_of_authors_orcid Authors_Orcid
rename countryname Country_Name
drop countrycode iso2code
distinct Country_Name
keep if year <= 2012

encode Country_Name, gen(country_id)
sort Country_Name year
xtset country_id year
tsfill, full

save "Authors.dta", replace

preserve
keep Country_Name country_id
drop if missing(Country_Name) | missing(country_id)
duplicates drop Country_Name, force
tempfile countries
save `countries'
restore
clear
set obs 24
gen year = 1987 + _n
tempfile years
save `years'
use `countries', clear
cross using `years'
sort Country_Name year
list Country_Name country_id year in 1/50
save "AllYears_8812.dta", replace

use "Authors.dta", clear
merge 1:1 country_id year using "AllYears_8812.dta"

sort country_id year
decode country_id, gen(Country_Name_str)
drop Country_Name _merge 
rename country_id Country_Name
drop Country_Name
rename Country_Name_str Country_Name
order Country_Name, first

save "Authors.dta", replace

******************** MERGE ALL CONTROLS ****************************************
use "Citation_Count_199Countries.dta", clear
merge 1:1 Country_Name year using "International_Collaboration_199Countries.dta"
drop _merge
merge 1:1 Country_Name year using "Scholarly_Output_199Countries.dta"
drop _merge
merge 1:1 Country_Name year using "Authors.dta"
keep if _merge == 3
drop _merge
distinct Country_Name
save "Controls.dta", replace

********************* CLEANING AND MERGING WUI *********************************
import delimited "WUI_Data.csv", varnames (1) clear

ds year, not
local vars `r(varlist)'
foreach var of varlist `vars' {
    rename `var' index_`var'
}
reshape long index_, i(year) j(country) string
gsort country year
gen year_num = real(substr(year, 1, 4))
collapse (mean) index_, by(country year_num)
rename year_num year
rename index_ wui

distinct country
drop if year < 1988
drop if year > 2012
gen iso_alpha3_code = upper(country)
drop country
save "annual_wui_8812.dta", replace

merge m:1 iso_alpha3_code using "List of Countries or Terretories.dta"
keep year wui iso_alpha3_code territory_name _merge
keep if _merge == 3
drop _merge iso_alpha3_code
rename territory_name Country_Name
distinct Country_Name

merge 1:1 Country_Name year using "Controls.dta"
keep if _merge == 3
distinct Country_Name
drop _merge

order Country_Name, first

save "Regressors.dta", replace

******************** CLEANING AND MERGING GDPPC ********************************
import delimited "Macroeconomic Controls.csv", varnames (1) clear
gen obs_id = _n           
gen total = _N 
drop if obs_id > total - 5
drop obs_id
drop total

forval y = 1988/2012 {
	rename yr`y' y`y'
}
foreach y of varlist y1988-y2012 {
	destring `y', replace ignore(", . $ n/a NA ..")
}
drop yr1987
reshape long y, i(countryname countrycode seriesname seriescode) j(year)
drop seriescode
rename y value
encode seriesname, gen(seriesname_id)
drop seriesname
reshape wide value, i(countrycode countryname year) j(seriesname_id)
rename value1 gdppc
rename value2 scitecharc
drop scitecharc countrycode
rename countryname Country_Name
save "Annual_GDPPC.dta", replace

use "Regressors.dta", clear
merge 1:1 Country_Name year using "Annual_GDPPC.dta"
keep if _merge == 3
drop _merge
save "Regressors.dta", replace

******************** CLEANING AND MERGING POP & GDPPCUS ************************
import delimited "Pop&GDPPCUS.csv", varnames (1) clear
gen obs_id = _n           
gen total = _N 
drop if obs_id > total - 5
drop obs_id
drop total

forval y = 1988/2012 {
	rename yr`y' y`y'
}
foreach y of varlist y1988-y2012 {
	destring `y', replace ignore(", . $ n/a NA ..")
}

reshape long y, i(countryname countrycode seriesname seriescode) j(year)
drop seriescode
rename y value
encode seriesname, gen(seriesname_id)
drop seriesname
reshape wide value, i(countrycode countryname year) j(seriesname_id)
rename value1 gdppcus
rename value2 pop
drop countrycode
rename countryname Country_Name
save "Annual_OtherMacroControls.dta", replace

use "Regressors.dta", clear
merge 1:1 Country_Name year using "Annual_OtherMacroControls.dta"
keep if _merge == 3
drop _merge
save "Regressors.dta", replace

********************** COUNTRY NAME TO ISO2 CODE *******************************
use "Regressors.dta", clear
rename Country_Name territory_name
merge m:1 territory_name using "/Users/steffinshibu/Desktop/Thesis Work/InvMigUndUncert/Data/List of Countries or Terretories.dta"
keep if _merge == 3
keep territory_name year wui Citation_Count International_Collaboration Scholarly_Output Authors_Scopus Authors_OpenAlex Authors_Orcid iso2_ori iso2_des gdppc gdppcus pop
order territory_name iso2_ori iso2_des year, first
save "Regressors.dta", replace  

********************** FIVE-YEAR MOVING AVERAGE ********************************
use "Regressors.dta", clear
encode territory_name, gen(terr_num)
sort terr_num year
rangestat (mean) wui_ma5=wui, interval(year -5 -1) by(iso2_ori)
rangestat (mean) citation_ma5=Citation_Count, interval(year -5 -1) by(iso2_ori)
rangestat (mean) collaboration_ma5=International_Collaboration, interval(year -5 -1) by(iso2_ori)
rangestat (mean) output_ma5=Scholarly_Output, interval(year -5 -1) by(iso2_ori)
rangestat (mean) scopus_ma5=Authors_Scopus, interval(year -5 -1) by(iso2_ori)
rangestat (mean) openalex_ma5=Authors_OpenAlex, interval(year -5 -1) by(iso2_ori)
rangestat (mean) orcid_ma5=Authors_Orcid, interval(year -5 -1) by(iso2_ori)
rangestat (mean) gdppc_ma5=gdppc, interval(year -5 -1) by(iso2_ori)
rangestat (mean) gdppcus_ma5=gdppcus, interval(year -5 -1) by(iso2_ori)
rangestat (mean) pop_ma5=pop, interval(year -5 -1) by(iso2_ori)
keep if year >= 1993

keep territory_name iso2_ori iso2_des year wui_ma5 citation_ma5 collaboration_ma5 output_ma5 scopus_ma5 openalex_ma5 orcid_ma5 gdppc_ma5 gdppcus_ma5 pop_ma5

save "MA_Regressors.dta", replace

********************** FIVE-YEAR WINDOW AVERAGE ********************************
use "Regressors.dta", clear

* Assigning windows
gen window = .
replace window = 0 if inrange(year,1988,1992)
replace window = 1 if inrange(year,1993,1997)
replace window = 2 if inrange(year,1998,2002)
replace window = 3 if inrange(year,2003,2007)
replace window = 4 if inrange(year,2008,2012)

collapse (mean) wui Citation_Count International_Collaboration Scholarly_Output Authors_Scopus Authors_OpenAlex Authors_Orcid gdppc gdppcus pop, by(territory_name iso2_ori iso2_des window)

gen window_label = ""
replace window_label = "1988-1992" if window==0
replace window_label = "1993-1997" if window==1
replace window_label = "1998-2002" if window==2
replace window_label = "2003-2007" if window==3
replace window_label = "2008-2012" if window==4

sort territory_name window
by territory_name: gen wui_shift = wui[_n-1]
by territory_name: gen citation_shift = Citation_Count[_n-1]
by territory_name: gen collaboration_shift = International_Collaboration[_n-1]
by territory_name: gen output_shift = Scholarly_Output[_n-1]
by territory_name: gen scopus_shift = Authors_Scopus[_n-1]
by territory_name: gen openalex_shift = Authors_OpenAlex[_n-1]
by territory_name: gen orcid_shift = Authors_Orcid[_n-1]
by territory_name: gen window_value = window_label[_n-1]
by territory_name: gen gdppc_shift = gdppc[_n-1]
by territory_name: gen gdppcus_shift = gdppcus[_n-1]
by territory_name: gen pop_shift = pop[_n-1]

drop if window == 0

keep territory_name iso2_ori iso2_des window_label window_value wui_shift citation_shift collaboration_shift output_shift scopus_shift openalex_shift orcid_shift gdppc_shift gdppcus_shift pop_shift

order territory_name iso2_ori iso2_des window_label window_value wui_shift citation_shift collaboration_shift output_shift scopus_shift openalex_shift orcid_shift gdppc_shift gdppcus_shift pop_shift,first

save "Window_Regressors.dta", replace

******************** CLEANING FLOW FOR MA **************************************
use "Bilateral flows.dta", clear
keep if inrange(prio_year, 1993, 2012)
drop if iso2_ori == iso2_des
rename prio_year year
sort iso2_ori iso2_des year
save "Bilateral flow_MA.dta", replace

******************** CLEANING FLOW FOR WINDOW **********************************
use "Bilateral flow_MA.dta", clear
gen window = .
replace window = 0 if inrange(year,1988,1992)
replace window = 1 if inrange(year,1993,1997)
replace window = 2 if inrange(year,1998,2002)
replace window = 3 if inrange(year,2003,2007)
replace window = 4 if inrange(year,2008,2012)

collapse (sum) flow, by(iso2_ori iso2_des window)

gen window_label = ""
replace window_label = "1988-1992" if window==0
replace window_label = "1993-1997" if window==1
replace window_label = "1998-2002" if window==2
replace window_label = "2003-2007" if window==3
replace window_label = "2008-2012" if window==4

drop if window == 0

save "Bilateral Flow_Window.dta", replace

********************* MA PANEL FOR ESTIMATION **********************************
use "Bilateral flow_MA.dta", clear
merge m:1 iso2_ori year using "MA_Regressors.dta", keepusing(wui_ma5 citation_ma5 collaboration_ma5 output_ma5 scopus_ma5 openalex_ma5 orcid_ma5 gdppc_ma5 gdppcus_ma5 pop_ma5)
rename wui_ma5 wui_ma5_ori
rename citation_ma5 citation_ma5_ori
rename collaboration_ma5 collaboration_ma5_ori
rename output_ma5 output_ma5_ori
rename scopus_ma5 scopus_ma5_ori
rename openalex_ma5 openalex_ma5_ori
rename orcid_ma5 orcid_ma5_ori
rename gdppc_ma5 gdppc_ma5_ori
rename gdppcus_ma5 gdppcus_ma5_ori
rename pop_ma5 pop_ma5_ori
keep if _merge == 3
drop _merge
save "MA_Regressors_ori.dta", replace

use "MA_Regressors.dta", clear
rename wui_ma5 wui_ma5_des
rename citation_ma5 citation_ma5_des
rename collaboration_ma5 collaboration_ma5_des
rename output_ma5 output_ma5_des
rename scopus_ma5 scopus_ma5_des
rename openalex_ma5 openalex_ma5_des
rename orcid_ma5 orcid_ma5_des
rename gdppc_ma5 gdppc_ma5_des
rename gdppcus_ma5 gdppcus_ma5_des
rename pop_ma5 pop_ma5_des
save "MA_Regressors_des.dta", replace

use "MA_Regressors_ori.dta", clear
merge m:1 iso2_des year using "MA_Regressors_des.dta"
keep if _merge == 3
drop _merge

sort iso2_ori iso2_des year
drop territory_name

order iso2_ori iso2_des year flow wui_ma5_des wui_ma5_ori citation_ma5_des citation_ma5_ori collaboration_ma5_des collaboration_ma5_ori output_ma5_des output_ma5_ori scopus_ma5_des scopus_ma5_ori openalex_ma5_des openalex_ma5_ori orcid_ma5_des orcid_ma5_ori gdppc_ma5_des gdppc_ma5_ori gdppcus_ma5_des gdppc_ma5_ori pop_ma5_des pop_ma5_ori, first

misstable summarize
distinct iso2_ori
distinct iso2_des
save "MA_Panel.dta", replace

********************* WINDOW PANEL FOR ESTIMATION ******************************
use "Bilateral flow_Window.dta", clear

merge m:1 iso2_ori window_label using "Window_Regressors.dta", keepusing(wui_shift citation_shift collaboration_shift output_shift scopus_shift openalex_shift orcid_shift gdppc_shift gdppcus_shift pop_shift)

rename wui_shift wui_shift_ori
rename citation_shift citation_shift_ori
rename collaboration_shift collaboration_shift_ori
rename output_shift output_shift_ori
rename scopus_shift scopus_shift_ori
rename openalex_shift openalex_shift_ori
rename orcid_shift orcid_shift_ori
rename gdppc_shift gdppc_shift_ori
rename gdppcus_shift gdppcus_shift_ori
rename pop_shift pop_shift_ori
keep if _merge == 3
drop _merge
save "Window_Regressors_ori.dta", replace

use "Window_Regressors.dta", clear
rename wui_shift wui_shift_des
rename citation_shift citation_shift_des
rename collaboration_shift collaboration_shift_des
rename output_shift output_shift_des
rename scopus_shift scopus_shift_des
rename openalex_shift openalex_shift_des
rename orcid_shift orcid_shift_des
rename gdppc_shift gdppc_shift_des
rename gdppcus_shift gdppcus_shift_des
rename pop_shift pop_shift_des
save "Window_Regressors_des.dta", replace

use "Window_Regressors_ori.dta", clear
merge m:1 iso2_des window_label using "Window_Regressors_des.dta"
keep if _merge == 3
drop _merge

sort iso2_ori iso2_des window_label
drop window territory_name

order iso2_ori iso2_des window_label window_value flow wui_shift_des wui_shift_ori collaboration_shift_des collaboration_shift_ori output_shift_des output_shift_ori scopus_shift_des scopus_shift_ori openalex_shift_des openalex_shift_ori orcid_shift_des orcid_shift_ori gdppc_shift_des gdppc_shift_ori gdppcus_shift_des gdppc_shift_ori pop_shift_des pop_shift_ori, first

misstable summarize
distinct iso2_ori
distinct iso2_des
save "Window_Panel.dta", replace

