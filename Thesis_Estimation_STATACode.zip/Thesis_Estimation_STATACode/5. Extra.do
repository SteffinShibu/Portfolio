*----------------------- STATIC (Collapsed) GROUPS --------------------------*
preserve
replace iso2_ori = upper(trim(iso2_ori))
collapse (mean) wui_shift_ori, by(iso2_ori)
egen grand_mean = mean(wui_shift_ori)
gen high_ori_sta = wui_shift_ori > grand_mean
keep iso2_ori high_ori_sta
save "_temp_static_tags_ori.dta", replace
restore

preserve
replace iso2_des = upper(trim(iso2_des))
collapse (mean) wui_shift_des, by(iso2_des)
egen grand_mean = mean(wui_shift_des)
gen high_des_sta = wui_shift_des > grand_mean
keep iso2_des high_des_sta
save "_temp_static_tags_des.dta", replace
restore

replace iso2_ori = upper(trim(iso2_ori))
merge m:1 iso2_ori using "_temp_static_tags_ori.dta"
drop _merge

replace iso2_des = upper(trim(iso2_des))
merge m:1 iso2_des using "_temp_static_tags_des.dta"
drop _merge

gen grp_sta_A = (high_ori_sta==1 & high_des_sta==0)
gen grp_sta_B = (high_ori_sta==1 & high_des_sta==1)
