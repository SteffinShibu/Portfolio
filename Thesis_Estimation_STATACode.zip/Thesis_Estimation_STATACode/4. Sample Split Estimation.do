********************************************************************************
*----------------------- ESTIMATION FOR TABLE 7 -------------------------------*
********************************************************************************

clear all
cd "/Users/steffinshibu/Desktop/Thesis Work/InvMigUndUncert/Data"

use "Window_Panel.dta", clear

gen rwui = ln(wui_shift_des)/ln(wui_shift_ori)

*---------------------- Generate Fixed Effects ----------------------*
egen dyad = group(iso2_ori iso2_des)
egen des_time_fe = group(iso2_des window_label)
egen ori_time_fe = group(iso2_ori window_label)

*----------------------- DYNAMIC (Window-wise) GROUPS -----------------------*
bysort window_label: egen mean_wui_ori_win = mean(wui_shift_ori)
bysort window_label: egen mean_wui_des_win = mean(wui_shift_des)

gen high_ori_dyn = wui_shift_ori > mean_wui_ori_win
gen high_des_dyn = wui_shift_des > mean_wui_des_win

gen grp_dyn_A = (high_ori_dyn==1 & high_des_dyn==0)
gen grp_dyn_B = (high_ori_dyn==0 & high_des_dyn==1)
gen grp_dyn_C = (high_ori_dyn==1 & high_des_dyn==1)
gen grp_dyn_D = (high_ori_dyn==0 & high_des_dyn==0)

tab grp_dyn_A
tab grp_dyn_B

*---------------------- PPML: MECHANISM GROUPS --------------------------------*
foreach g in A B C D {
    di "========== Dynamic group `g' =========="
    ppmlhdfe flow rwui if grp_dyn_`g'==1, absorb(dyad ori_time_fe des_time_fe) vce(cluster dyad)
    estimates store dyn`g'
}

outreg2 [dynA dynB dynC dynD] using "Mechanism_Groups_NoControls.doc", ///
    replace label addstat(Pseudo-R2, e(r2_p))

*--------------------- OLS: MECHANISM GROUPS (Table 9) ------------------------*	
foreach g in A B C D {
    di "========== Dynamic group `g' =========="
    reghdfe flow rwui if grp_dyn_`g'==1, absorb(dyad ori_time_fe des_time_fe) vce(cluster dyad)
    estimates store dyn`g'
}

outreg2 [dynA dynB dynC dynD] using "NewTable9.doc", ///
    append label addstat(Adjusted R^2, e(r2_a)) ///
	addtext("Three-way FE", "Yes")
